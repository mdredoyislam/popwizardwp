<script type="text/html" id="tmpl-piklist-shortcode-inline">
  <span class="piklist-shortcode-inline mceItem">
    {{ data.preview }}
  </span>
</script>
