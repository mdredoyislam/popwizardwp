
<div id="major-publishing-actions" class="piklist-major-publishing-actions">

  <div id="publishing-action">

    <?php echo submit_button(esc_html__($save_text), 'primary', 'submit', false); ?>
    
  </div>
  
  <div class="clear"></div>
  
</div>
  