
<form 
  method="get" 
  id="<?php echo $form_id; ?>"
>

  <?php $list_table->display(); ?>
  
</form>
