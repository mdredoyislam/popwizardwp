<?php
/*
Page: shortcode_editor
*/

  echo do_shortcode('[piklist_form form="shortcode"]');