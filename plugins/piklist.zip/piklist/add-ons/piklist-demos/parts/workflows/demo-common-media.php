<?php
/*
Title: Media
Order: 1
Flow: Demo Workflow
Page: post.php
Post Type: attachment
Tab: Common
Default Form: true
*/