<?php
/*
Title: Piklist Demos are activated
Anchor ID: #menu-posts-piklist_demo
Edge: left
Align: center
*/
?>

<p><?php printf(__('Many of the Demos can be found here. In addition, Piklist also created a %1$sDemo Widget %2$s, and added fields to your %3$sUser Profile %2$s and %4$sMedia Attachments%2$s.', 'piklist'),'<a href="' . network_admin_url() . 'widgets.php">', '</a>', '<a href="' . network_admin_url() . 'profile.php">','<a href="' . network_admin_url() . 'upload.php">');?></p>