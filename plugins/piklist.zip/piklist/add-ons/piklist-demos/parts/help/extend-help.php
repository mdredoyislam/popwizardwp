<?php
/*
Title: Hello Help
Extend: piklist_demos_demos_help
Extend Method: after
*/
?>

<p>
  <?php _e('This dashboard widget has been extended with Piklist.'); ?>
</p>